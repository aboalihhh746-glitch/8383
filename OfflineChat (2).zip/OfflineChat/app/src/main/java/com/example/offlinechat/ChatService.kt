package com.example.offlinechat

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class ChatService : Service() {
    companion object {
        const val CH_SVC = "svc"
        const val CH_MSG = "msg"
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ChatService::class.java))
        }
    }

    private var engine: P2PEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_SVC)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("الدردشة المحلية تعمل")
            .setContentText("جاهز لاستقبال الرسائل من الأجهزة القريبة")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val name = Prefs.username(this)
        if (name == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (engine == null) {
            engine = P2PEngine(this, AppDatabase.get(this), name).also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        super.onDestroy()
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SVC, "حالة الخدمة", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MSG, "الرسائل", NotificationManager.IMPORTANCE_HIGH)
        )
    }
}
