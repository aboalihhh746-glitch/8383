package com.example.offlinechat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

object Net {
    const val SERVICE_TYPE = "_offlinechat._tcp."
    const val DEFAULT_PORT = 8888

    /** اسم المحادثة المفتوحة حالياً (لتجنّب إشعار الرسائل أثناء قراءتها) */
    @Volatile var openChat: String? = null

    /** يرسل رسالة JSON عبر Socket مباشر ويغلق الاتصال فوراً. يعيد true عند النجاح. */
    suspend fun send(db: AppDatabase, myName: String, peer: User, text: String): Boolean =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val json = JSONObject()
                .put("senderName", myName)
                .put("messageText", text)
                .put("timestamp", now)
                .toString()
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(peer.ipAddress, peer.port), 3000)
                    s.soTimeout = 3000
                    s.getOutputStream().apply {
                        write((json + "\n").toByteArray(Charsets.UTF_8))
                        flush()
                    }
                }
                db.messageDao().insert(
                    Message(peerName = peer.username, messageText = text, timestamp = now, isSentByMe = true)
                )
                true
            } catch (e: IOException) {
                false
            }
        }
}
