package com.example.offlinechat

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "users", indices = [Index(value = ["username"], unique = true)])
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val ipAddress: String,
    val port: Int,
    val lastSeen: Long,
    val isOnline: Boolean = true
)

// الرسائل مرتبطة باسم الطرف الآخر (وليس الـ IP) حتى لا يضيع السجل عند تغيّر العنوان
@Entity(tableName = "messages", indices = [Index("peerName")])
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val peerName: String,
    val messageText: String,
    val timestamp: Long,
    val isSentByMe: Boolean
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY isOnline DESC, username")
    fun observeAll(): Flow<List<User>>

    @Query("SELECT * FROM users WHERE username = :name LIMIT 1")
    fun observe(name: String): Flow<User?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: User): Long

    @Query("UPDATE users SET isOnline = 0 WHERE username = :name")
    suspend fun setOffline(name: String)

    @Query("UPDATE users SET isOnline = 0")
    suspend fun setAllOffline()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE peerName = :peer ORDER BY timestamp, id")
    fun observeChat(peer: String): Flow<List<Message>>

    @Insert
    suspend fun insert(message: Message): Long
}

@Database(entities = [User::class, Message::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "chat.db")
                .build().also { instance = it }
        }
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun username(c: Context): String? = sp(c).getString("username", null)
    fun save(c: Context, name: String) = sp(c).edit().putString("username", name).apply()
}
