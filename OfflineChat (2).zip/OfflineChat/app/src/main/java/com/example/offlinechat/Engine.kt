package com.example.offlinechat

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/** الاكتشاف (NSD) + خادم الاستقبال (ServerSocket) + مراقبة تغيّر الشبكة. */
class P2PEngine(context: Context, private val db: AppDatabase, private val myName: String) {
    private val TAG = "P2PEngine"
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var server: ServerSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private var regListener: NsdManager.RegistrationListener? = null
    private var discListener: NsdManager.DiscoveryListener? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private val firstCallback = AtomicBoolean(true)
    private val resolveQueue = Channel<NsdServiceInfo>(Channel.UNLIMITED)
    @Volatile private var registeredName = myName

    fun start() {
        // بدون MulticastLock قد يتجاهل النظام حزم الاكتشاف لتوفير البطارية
        lock = wifi.createMulticastLock("offlinechat").apply {
            setReferenceCounted(false)
            acquire()
        }
        scope.launch { db.userDao().setAllOffline() }

        val s = try { ServerSocket(Net.DEFAULT_PORT) } catch (e: IOException) { ServerSocket(0) }
        server = s
        scope.launch { acceptLoop(s) }

        // NSD يسمح بعملية resolve واحدة في كل مرة، لذلك نستخدم طابوراً
        scope.launch { for (info in resolveQueue) resolveOne(info) }

        startNsd(s.localPort)

        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (firstCallback.getAndSet(false)) return
                // اتصلنا بشبكة جديدة أو تغيّر الـ IP: أعد التسجيل والبحث
                scope.launch { delay(1500); restartNsd() }
            }
            override fun onLost(network: Network) {
                scope.launch { db.userDao().setAllOffline() }
            }
        }
        netCallback = cb
        cm.registerDefaultNetworkCallback(cb)
    }

    fun stop() {
        runCatching { netCallback?.let { cm.unregisterNetworkCallback(it) } }
        stopNsd()
        runCatching { server?.close() }
        runCatching { lock?.takeIf { it.isHeld }?.release() }
        resolveQueue.close()
        scope.cancel()
    }

    // ---------- NSD ----------
    private fun startNsd(port: Int) {
        try {
            val info = NsdServiceInfo().apply {
                serviceName = myName
                serviceType = Net.SERVICE_TYPE
                setPort(port)
            }
            val reg = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) { registeredName = i.serviceName }
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) { Log.e(TAG, "register failed $e") }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            regListener = reg
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg)

            val disc = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, e: Int) { Log.e(TAG, "discovery failed $e") }
                override fun onStopDiscoveryFailed(t: String, e: Int) {}
                override fun onServiceFound(i: NsdServiceInfo) {
                    if (i.serviceType.contains("_offlinechat") && i.serviceName != registeredName) {
                        resolveQueue.trySend(i)
                    }
                }
                override fun onServiceLost(i: NsdServiceInfo) {
                    scope.launch { db.userDao().setOffline(i.serviceName) }
                }
            }
            discListener = disc
            nsd.discoverServices(Net.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, disc)
        } catch (e: Exception) {
            Log.e(TAG, "startNsd", e)
        }
    }

    private fun stopNsd() {
        runCatching { regListener?.let { nsd.unregisterService(it) } }
        runCatching { discListener?.let { nsd.stopServiceDiscovery(it) } }
        regListener = null
        discListener = null
    }

    private fun restartNsd() {
        val port = server?.localPort ?: return
        stopNsd()
        startNsd(port)
    }

    @Suppress("DEPRECATION")
    private suspend fun resolveOne(info: NsdServiceInfo) {
        val resolved = withTimeoutOrNull(5000) {
            suspendCancellableCoroutine<NsdServiceInfo?> { cont ->
                nsd.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(i: NsdServiceInfo, e: Int) { if (cont.isActive) cont.resume(null) }
                    override fun onServiceResolved(i: NsdServiceInfo) { if (cont.isActive) cont.resume(i) }
                })
            }
        } ?: return
        val name = resolved.serviceName
        val host = resolved.host?.hostAddress ?: return
        if (name == registeredName) return
        // upsert يحدّث الـ IP تلقائياً إذا تغيّر عنوان الجهاز
        db.userDao().upsert(
            User(username = name, ipAddress = host, port = resolved.port,
                lastSeen = System.currentTimeMillis(), isOnline = true)
        )
    }

    // ---------- Sockets ----------
    private suspend fun acceptLoop(s: ServerSocket) {
        while (scope.isActive && !s.isClosed) {
            try {
                val c = s.accept()
                scope.launch { handle(c) }
            } catch (e: IOException) {
                break
            }
        }
    }

    private fun readLine(s: Socket): String? {
        val inp = BufferedInputStream(s.getInputStream())
        val buf = ByteArrayOutputStream()
        while (buf.size() < 65536) {
            val b = inp.read()
            if (b == -1 || b == '\n'.code) break
            buf.write(b)
        }
        return if (buf.size() == 0) null else buf.toString("UTF-8")
    }

    private suspend fun handle(c: Socket) {
        try {
            c.use {
                it.soTimeout = 5000   // لا نترك اتصالاً معلّقاً
                val line = readLine(it) ?: return
                val j = JSONObject(line)
                val from = j.getString("senderName").trim()
                val text = j.getString("messageText")
                if (from.isEmpty() || text.isBlank()) return
                db.messageDao().insert(
                    // نستخدم وقت الاستلام لأن ساعات الأجهزة قد تختلف
                    Message(peerName = from, messageText = text,
                        timestamp = System.currentTimeMillis(), isSentByMe = false)
                )
                if (Net.openChat != from) notifyIncoming(from, text)
            }
        } catch (e: Exception) {
            Log.w(TAG, "bad incoming message", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun notifyIncoming(from: String, text: String) {
        val pi = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, ChatService.CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(from)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        val nm = NotificationManagerCompat.from(ctx)
        if (nm.areNotificationsEnabled()) nm.notify(from.hashCode(), n)
    }
}
