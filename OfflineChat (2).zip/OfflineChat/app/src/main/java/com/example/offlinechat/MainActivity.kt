package com.example.offlinechat

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private fun neededPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.POST_NOTIFICATIONS)
    else
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

@Composable
fun App() {
    val ctx = LocalContext.current
    var username by remember { mutableStateOf(Prefs.username(ctx)) }
    var chatWith by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { ChatService.start(ctx) }

    LaunchedEffect(username) {
        if (username != null) launcher.launch(neededPermissions())
    }
    BackHandler(chatWith != null) { chatWith = null }

    val me = username
    val peer = chatWith
    when {
        me == null -> RegisterScreen { name -> Prefs.save(ctx, name); username = name }
        peer == null -> PeersScreen(me) { chatWith = it }
        else -> ChatScreen(me, peer) { chatWith = null }
    }
}

@Composable
fun RegisterScreen(onDone: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("مرحباً بك في الدردشة المحلية", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("اكتب اسمك ليراك الآخرون على نفس الشبكة")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { if (it.length <= 30) name = it },
            label = { Text("اسم المستخدم") },
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onDone(name.trim()) }, enabled = name.isNotBlank()) { Text("ابدأ") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeersScreen(me: String, onOpen: (String) -> Unit) {
    val db = AppDatabase.get(LocalContext.current)
    val peers by db.userDao().observeAll().collectAsState(emptyList())
    Scaffold(topBar = { TopAppBar(title = { Text("الأجهزة القريبة — $me") }) }) { pad ->
        if (peers.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("جارٍ البحث عن أجهزة على نفس الشبكة…")
            }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(peers, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text(p.username) },
                        supportingContent = {
                            Text(if (p.isOnline) "متصل · ${p.ipAddress}" else "غير متصل")
                        },
                        leadingContent = {
                            Box(
                                Modifier.size(12.dp).background(
                                    if (p.isOnline) Color(0xFF2E7D32) else Color.Gray, CircleShape
                                )
                            )
                        },
                        modifier = Modifier.clickable { onOpen(p.username) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(me: String, peerName: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppDatabase.get(ctx)
    val scope = rememberCoroutineScope()
    val msgs by db.messageDao().observeChat(peerName).collectAsState(emptyList())
    val peer by db.userDao().observe(peerName).collectAsState(null)
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    DisposableEffect(peerName) {
        Net.openChat = peerName
        onDispose { Net.openChat = null }
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(peerName) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
                state = listState
            ) {
                items(msgs, key = { it.id }) { m ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = if (m.isSentByMe) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (m.isSentByMe) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Text(m.messageText)
                                Text(
                                    fmt.format(Date(m.timestamp)),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("اكتب رسالة") }
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val t = text.trim()
                    val p = peer
                    if (t.isNotEmpty() && p != null) {
                        text = ""
                        scope.launch {
                            if (!Net.send(db, me, p, t)) {
                                text = t
                                Toast.makeText(ctx, "تعذّر الإرسال، الجهاز غير متاح", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }) { Text("إرسال") }
            }
        }
    }
}
